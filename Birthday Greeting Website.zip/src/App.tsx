import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";

/* =====================================================================
   CONFIG — chỉ cần sửa object này để đổi toàn bộ nội dung.
   - photos: danh sách đường dẫn ảnh (đặt ảnh trong public/assets/images,
     ví dụ "assets/images/anh1.jpg"). Để "" sẽ dùng ảnh placeholder.
   - audioSrc: đường dẫn mp3 (vd "assets/audio/nhac.mp3").
     Để "" hoặc file không tồn tại thì dùng giai điệu Happy Birthday tự tạo.
   - Luôn dùng đường dẫn TƯƠNG ĐỐI (không bắt đầu bằng "/") để chạy
     đúng trên GitHub Pages.
   ===================================================================== */
const CONFIG = {
  fullName: "Trần Thị Hồng Loan",
  shortName: "Hồng Loan",
  nameLines: ["Trần Thị", "Hồng Loan"], // tên xếp bằng hạt (chia dòng cho vừa màn hình điện thoại)
  birthday: "07/10/2009",
  age: 17,
  sender: "Nguyễn Mạnh Cường",
  audioSrc: "",
  wishes: [
    "Chúc Loan tuổi 17 thật rực rỡ, như chính ánh sáng của những vì sao tối nay.",
    "Chúc mọi điều ước bạn thầm thì đều tìm được đường để thành hiện thực.",
    "Chúc bạn luôn khỏe mạnh, luôn được yêu thương và luôn dám mơ những giấc mơ thật lớn.",
    "Và mong rằng, dù ở bất cứ đâu, bạn cũng nhớ rằng có một người luôn tự hào về bạn.",
  ],
  letter: [
    "Gửi Loan,",
    "Mình không giỏi nói những lời hoa mỹ, nên hôm nay mình viết ra đây.",
    "Tuổi 17 là tuổi của những ngã rẽ đầu tiên, và mình mong mỗi ngã rẽ của bạn đều có ánh sáng.",
    "Cảm ơn bạn vì đã xuất hiện và làm cho những ngày bình thường của mình trở nên đáng nhớ hơn.",
    "Sinh nhật vui nhé, Hồng Loan!",
  ],
  photos: [
    { src: "", alt: "Ảnh kỷ niệm 1" },
    { src: "", alt: "Ảnh kỷ niệm 2" },
    { src: "", alt: "Ảnh kỷ niệm 3" },
    { src: "", alt: "Ảnh kỷ niệm 4" },
    { src: "", alt: "Ảnh kỷ niệm 5" },
    { src: "", alt: "Ảnh kỷ niệm 6" },
    { src: "", alt: "Ảnh kỷ niệm 7" },
    { src: "", alt: "Ảnh kỷ niệm 8" },
  ],
};

/* ---------- Tiện ích chung ---------- */
const isMobile = () => typeof window !== "undefined" && window.innerWidth < 640;
const GLOW = ["#ff74b8", "#ffd479", "#ffb3d9", "#fff1c2", "#c9b6ff"];
const rand = (a: number, b: number) => a + Math.random() * (b - a);

const PALETTES = [
  ["#3a2a8c", "#ff74b8"],
  ["#2a1b6b", "#ffd479"],
  ["#4b2a9c", "#ff9ccf"],
  ["#1d1a6b", "#c9b6ff"],
];
const EMOJI = ["🌙", "🎂", "💫", "🎀", "🌸", "✨", "💖", "🎈"];

// Ảnh placeholder bằng SVG khi chưa có ảnh thật
function placeholder(i: number, w = 600, h = 800) {
  const [a, b] = PALETTES[i % PALETTES.length];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><circle cx="${w * 0.8}" cy="${h * 0.18}" r="${w * 0.22}" fill="#fff" fill-opacity=".18"/><text x="50%" y="52%" font-size="${w * 0.3}" text-anchor="middle" dominant-baseline="middle">${EMOJI[i % EMOJI.length]}</text></svg>`;
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

function useReducedMotion() {
  const [r, setR] = useState(false);
  useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    setR(m.matches);
    const f = () => setR(m.matches);
    m.addEventListener("change", f);
    return () => m.removeEventListener("change", f);
  }, []);
  return r;
}

function useSeen(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return [ref, seen] as const;
}

function Reveal({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const [ref, seen] = useSeen(0.15);
  return (
    <div ref={ref} className={`reveal ${seen ? "in" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------- Pháo giấy (canvas 2D) ---------- */
type Piece = { x: number; y: number; vx: number; vy: number; w: number; h: number; rot: number; vr: number; c: string };

function useConfetti(reduced: boolean) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pieces = useRef<Piece[]>([]);
  const raf = useRef(0);

  const loop = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    ctx.clearRect(0, 0, cv.width, cv.height);
    pieces.current = pieces.current.filter((p) => p.y < cv.height + 30);
    for (const p of pieces.current) {
      p.vy += 0.15;
      p.vx *= 0.99;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.vr;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.c;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    raf.current = pieces.current.length ? requestAnimationFrame(loop) : 0;
  }, []);

  useEffect(() => {
    const resize = () => {
      const cv = canvasRef.current;
      if (!cv) return;
      cv.width = window.innerWidth;
      cv.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(raf.current);
    };
  }, []);

  const fire = useCallback(
    (x = 0.5, y = 0.5, count = 90) => {
      const cv = canvasRef.current;
      if (!cv) return;
      const n = Math.round((reduced ? count / 4 : count) * (isMobile() ? 0.7 : 1));
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = rand(3, 10);
        pieces.current.push({
          x: x * cv.width,
          y: y * cv.height,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s - 5,
          w: rand(6, 12),
          h: rand(4, 9),
          rot: rand(0, 6),
          vr: rand(-0.2, 0.2),
          c: GLOW[(Math.random() * GLOW.length) | 0],
        });
      }
      if (!raf.current) raf.current = requestAnimationFrame(loop);
    },
    [loop, reduced],
  );

  return { canvasRef, fire };
}

/* ---------- Nhạc nền ---------- */
// Giai điệu Happy Birthday dự phòng: [tần số Hz, số phách]
const MELODY: [number, number][] = [
  [392, 0.75], [392, 0.25], [440, 1], [392, 1], [523.25, 1], [493.88, 2],
  [392, 0.75], [392, 0.25], [440, 1], [392, 1], [587.33, 1], [523.25, 2],
  [392, 0.75], [392, 0.25], [783.99, 1], [659.25, 1], [523.25, 1], [493.88, 1], [440, 1],
  [698.46, 0.75], [698.46, 0.25], [659.25, 1], [523.25, 1], [587.33, 1], [523.25, 2],
];

function useMusic() {
  const [playing, setPlaying] = useState(false);
  const ctxRef = useRef<AudioContext | null>(null);
  const timer = useRef(0);
  const audioEl = useRef<HTMLAudioElement | null>(null);

  const schedule = useCallback((ctx: AudioContext, start: number) => {
    const beat = 0.55;
    let t = start;
    for (const [f, b] of MELODY) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.16, t + 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t + b * beat * 0.97);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + b * beat);
      t += b * beat;
    }
    timer.current = window.setTimeout(() => schedule(ctx, ctx.currentTime + 0.1), (t - ctx.currentTime + 1.5) * 1000);
  }, []);

  const startSynth = useCallback(() => {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    if (!ctxRef.current) {
      ctxRef.current = new AC();
      schedule(ctxRef.current, ctxRef.current.currentTime + 0.1);
    }
    ctxRef.current.resume();
    setPlaying(true);
  }, [schedule]);

  const start = useCallback(() => {
    if (!CONFIG.audioSrc) return startSynth();
    if (!audioEl.current) {
      audioEl.current = new Audio(CONFIG.audioSrc);
      audioEl.current.loop = true;
    }
    audioEl.current.play().then(() => setPlaying(true)).catch(() => {
      audioEl.current = null;
      startSynth(); // file mp3 thiếu → dùng nhạc dự phòng
    });
  }, [startSynth]);

  const stop = useCallback(() => {
    audioEl.current?.pause();
    ctxRef.current?.suspend();
    setPlaying(false);
  }, []);

  useEffect(() => () => clearTimeout(timer.current), []);
  return { playing, start, stop };
}

/* ---------- Nền sao lấp lánh ---------- */
function StarField({ reduced }: { reduced: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    let w = 0, h = 0, raf = 0;
    const count = isMobile() ? 90 : 180;
    const stars = Array.from({ length: count }, () => ({
      x: Math.random(), y: Math.random(), r: rand(0.4, 1.5), p: rand(0, 6), s: rand(0.6, 2),
    }));
    let shoot: { x: number; y: number; life: number } | null = null;
    const resize = () => {
      w = cv.width = window.innerWidth;
      h = cv.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      for (const s of stars) {
        const a = reduced ? 0.7 : 0.35 + 0.65 * Math.abs(Math.sin(t / 1000 * s.s + s.p));
        ctx.fillStyle = `rgba(255,245,225,${a})`;
        ctx.beginPath();
        ctx.arc(s.x * w, s.y * h, s.r, 0, 6.3);
        ctx.fill();
      }
      if (!reduced) {
        if (!shoot && Math.random() < 0.004) shoot = { x: rand(0.2, 1) * w, y: rand(0, 0.4) * h, life: 0 };
        if (shoot) {
          shoot.life += 1;
          const k = shoot.life * 9;
          const g = ctx.createLinearGradient(shoot.x - k, shoot.y + k * 0.6, shoot.x - k - 80, shoot.y + k * 0.6 + 48);
          g.addColorStop(0, "rgba(255,255,255,0.9)");
          g.addColorStop(1, "rgba(255,255,255,0)");
          ctx.strokeStyle = g;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(shoot.x - k, shoot.y + k * 0.6);
          ctx.lineTo(shoot.x - k - 80, shoot.y + k * 0.6 + 48);
          ctx.stroke();
          if (shoot.life > 40) shoot = null;
        }
        raf = requestAnimationFrame(draw);
      }
    };
    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [reduced]);
  return <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 z-0" />;
}

/* ---------- Cảnh hạt xếp chữ + pháo hoa ---------- */
type Dot = { x: number; y: number; vx: number; vy: number; tx: number; ty: number; r: number; c: string };
type Spark = { x: number; y: number; vx: number; vy: number; life: number; max: number; c: string; rocket: boolean };

// Lấy các điểm từ chữ bằng cách vẽ chữ lên canvas ẩn rồi đọc pixel
function textTargets(lines: string[], W: number, H: number, max: number) {
  const off = document.createElement("canvas");
  off.width = W;
  off.height = H;
  const c = off.getContext("2d", { willReadFrequently: true })!;
  let size = Math.min(H * 0.26, W * 0.45);
  const font = (s: number) => `700 ${s}px "Dancing Script", cursive`;
  c.font = font(size);
  const widest = Math.max(...lines.map((l) => c.measureText(l).width));
  size *= Math.min(1, (W * 0.86) / widest);
  c.font = font(size);
  c.fillStyle = "#fff";
  c.textAlign = "center";
  c.textBaseline = "middle";
  const lh = size * 1.12;
  lines.forEach((l, i) => c.fillText(l, W / 2, H / 2 + (i - (lines.length - 1) / 2) * lh));
  const data = c.getImageData(0, 0, W, H).data;
  const gap = Math.max(2, Math.round(size / 28));
  const pts: [number, number][] = [];
  for (let y = 0; y < H; y += gap)
    for (let x = 0; x < W; x += gap) if (data[(y * W + x) * 4 + 3] > 128) pts.push([x, y]);
  for (let i = pts.length - 1; i > 0; i--) {
    const j = (Math.random() * (i + 1)) | 0;
    [pts[i], pts[j]] = [pts[j], pts[i]];
  }
  return pts.slice(0, max);
}

// Điểm trên hình trái tim (phương trình tham số), một nửa viền, một nửa lấp đầy
function heartTargets(W: number, H: number, n: number) {
  const k = Math.min(W * 0.72, H * 0.5) / 34;
  const pts: [number, number][] = [];
  for (let i = 0; i < n; i++) {
    const t = Math.random() * Math.PI * 2;
    const s = i % 2 ? 1 : Math.sqrt(Math.random());
    const x = 16 * Math.sin(t) ** 3;
    const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
    pts.push([W / 2 + x * k * s, H / 2 - y * k * s + k * 2]);
  }
  return pts;
}

function ParticleScene({ onDone }: { onDone: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext("2d")!;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = window.innerWidth, H = window.innerHeight;
    cv.width = W * dpr;
    cv.height = H * dpr;
    ctx.scale(dpr, dpr);

    const N = isMobile() ? 750 : 1500;
    const dots: Dot[] = Array.from({ length: N }, () => {
      const a = rand(0, 6.28), d = Math.max(W, H) * rand(0.6, 0.9);
      return { x: W / 2 + Math.cos(a) * d, y: H / 2 + Math.sin(a) * d, vx: 0, vy: 0, tx: W / 2, ty: H / 2, r: rand(0.9, 2), c: GLOW[(Math.random() * GLOW.length) | 0] };
    });
    const sparks: Spark[] = [];
    let raf = 0, cancelled = false;
    let beat = false;
    let scatterUntil = 0;

    // Các giai đoạn: chữ Happy Birthday → tên → trái tim
    const phases = [
      { hold: 3200, targets: () => textTargets(["Happy", "Birthday"], W, H, N) },
      { hold: 3200, targets: () => textTargets(CONFIG.nameLines, W, H, N) },
      { hold: 4600, targets: () => heartTargets(W, H, N) },
    ];

    const assign = (pts: [number, number][]) => {
      dots.forEach((d, i) => {
        const p = pts[i % pts.length];
        d.tx = p[0];
        d.ty = p[1];
      });
    };

    const scatter = (now: number) => {
      scatterUntil = now + 650;
      for (const d of dots) {
        const a = rand(0, 6.28), s = rand(2, 7);
        d.vx = Math.cos(a) * s;
        d.vy = Math.sin(a) * s;
      }
    };

    const burst = (x: number, y: number) => {
      const n = isMobile() ? 26 : 44;
      const c = GLOW[(Math.random() * GLOW.length) | 0];
      for (let i = 0; i < n; i++) {
        const a = (i / n) * 6.28 + rand(-0.1, 0.1), s = rand(1.5, 4.5);
        sparks.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0, max: rand(50, 80), c, rocket: false });
      }
    };
    const launch = () => {
      sparks.push({ x: rand(0.12, 0.88) * W, y: H, vx: rand(-0.6, 0.6), vy: -rand(8, 11), life: 0, max: 999, c: "#fff", rocket: true });
    };

    let phase = -1, phaseEnd = 0, nextRocket = 0;
    const t0 = performance.now();

    const frame = (now: number) => {
      if (cancelled) return;
      if (now > phaseEnd) {
        phase++;
        if (phase >= phases.length) return onDone();
        if (phase > 0) scatter(now);
        assign(phases[phase].targets());
        phaseEnd = now + phases[phase].hold;
        beat = phase === 2;
        for (let i = 0; i < 3; i++) setTimeout(() => !cancelled && burst(rand(0.15, 0.85) * W, rand(0.15, 0.4) * H), i * 250);
      }
      if (now > nextRocket) {
        launch();
        nextRocket = now + rand(500, 950);
      }

      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = "lighter";

      // Pháo hoa phía sau
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i];
        s.x += s.vx;
        s.y += s.vy;
        if (s.rocket) {
          s.vy += 0.1;
          ctx.fillStyle = "rgba(255,230,180,0.9)";
          ctx.fillRect(s.x, s.y, 2, 6);
          if (s.vy > -1) {
            burst(s.x, s.y);
            sparks.splice(i, 1);
          }
          continue;
        }
        s.vy += 0.045;
        s.vx *= 0.985;
        s.life++;
        const a = 1 - s.life / s.max;
        if (a <= 0) {
          sparks.splice(i, 1);
          continue;
        }
        ctx.globalAlpha = a * 0.8;
        ctx.fillStyle = s.c;
        ctx.beginPath();
        ctx.arc(s.x, s.y, 1.8, 0, 6.3);
        ctx.fill();
      }

      // Hạt xếp chữ
      const pulse = beat ? 1 + 0.045 * Math.sin((now - t0) / 140) : 1;
      const free = now < scatterUntil;
      for (const d of dots) {
        if (free) {
          d.vx *= 0.97;
          d.vy *= 0.97;
        } else {
          const tx = beat ? W / 2 + (d.tx - W / 2) * pulse : d.tx;
          const ty = beat ? H / 2 + (d.ty - H / 2) * pulse : d.ty;
          d.vx += (tx - d.x) * 0.045;
          d.vy += (ty - d.y) * 0.045;
          d.vx *= 0.84;
          d.vy *= 0.84;
        }
        d.x += d.vx;
        d.y += d.vy;
        ctx.globalAlpha = 0.18;
        ctx.fillStyle = d.c;
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r * 3, 0, 6.3);
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r, 0, 6.3);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
      raf = requestAnimationFrame(frame);
    };

    // Đợi font viết tay tải xong rồi mới lấy điểm
    const start = () => !cancelled && (raf = requestAnimationFrame(frame));
    document.fonts.load('700 100px "Dancing Script"').then(start, start);
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [onDone]);

  return <canvas ref={ref} aria-hidden className="fixed inset-0 z-[40] h-full w-full" />;
}

/* ---------- Tiêu đề section ---------- */
function Title({ eyebrow, children }: { eyebrow: string; children: ReactNode }) {
  return (
    <Reveal className="mb-10 text-center">
      <p className="mb-1 text-xs font-medium uppercase tracking-[0.3em] text-pink">{eyebrow}</p>
      <h2 className="glow-gold font-script text-5xl font-bold text-gold md:text-6xl">{children}</h2>
    </Reveal>
  );
}

/* ---------- Bánh kem + thổi nến (micro hoặc chạm) ---------- */
const AGE = CONFIG.age;
const CAN_X = (i: number) => 86 + i * (228 / (AGE - 1));
const CAN_Y = (i: number) => 128 + (i % 2 ? -5 : 0);

// Đường viền kem chảy: các nửa vòng cung rũ xuống
function dripPath(x0: number, x1: number, y: number, n: number) {
  const w = (x1 - x0) / n;
  let d = `M${x0} ${y - 16} H${x1} V${y}`;
  for (let i = 0; i < n; i++) d += ` a${w / 2} ${8 + (i % 3) * 5} 0 0 1 ${-w} 0`;
  return d + " Z";
}

function Cake({ fire }: { fire: (x?: number, y?: number, n?: number) => void }) {
  const [lit, setLit] = useState<boolean[]>(() => Array(AGE).fill(true));
  const [mic, setMic] = useState<"idle" | "on" | "denied">("idle");
  const stopMic = useRef<() => void>(() => {});
  const allOut = lit.every((l) => !l);
  const left = lit.filter(Boolean).length;

  const blowRandom = useCallback(() => {
    setLit((prev) => {
      const idx = prev.map((l, i) => (l ? i : -1)).filter((i) => i >= 0);
      if (!idx.length) return prev;
      const pick = idx[(Math.random() * idx.length) | 0];
      return prev.map((l, i) => (i === pick ? false : l));
    });
  }, []);

  // Chạm vào mặt bánh: tắt ngọn nến gần nhất và hai ngọn bên cạnh
  const tap = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const fx = ((e.clientX - r.left) / r.width) * 400;
    setLit((prev) => {
      let best = -1, dist = 1e9;
      prev.forEach((l, i) => {
        const d = Math.abs(CAN_X(i) - fx);
        if (l && d < dist) { dist = d; best = i; }
      });
      if (best < 0) return prev;
      return prev.map((l, i) => (Math.abs(i - best) <= 1 ? false : l));
    });
  };

  const startMic = async () => {
    if (!navigator.mediaDevices?.getUserMedia) return setMic("denied");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AC();
      const an = ctx.createAnalyser();
      an.fftSize = 1024;
      ctx.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      let base = 0, frames = 0, loud = 0, last = 0, raf = 0;
      const tick = (t: number) => {
        an.getByteTimeDomainData(buf);
        let sum = 0;
        for (const v of buf) sum += ((v - 128) / 128) ** 2;
        const rms = Math.sqrt(sum / buf.length);
        if (frames < 30) {
          base = Math.max(base, rms); // đo tiếng ồn nền lúc đầu
          frames++;
        } else if (rms > Math.max(0.1, base * 2.5)) {
          loud++;
          if (loud > 6 && t - last > 120) {
            blowRandom();
            last = t;
          }
        } else loud = Math.max(0, loud - 1);
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      stopMic.current = () => {
        cancelAnimationFrame(raf);
        stream.getTracks().forEach((tr) => tr.stop());
        ctx.close();
      };
      setMic("on");
    } catch {
      setMic("denied");
    }
  };

  useEffect(() => {
    if (allOut) {
      stopMic.current();
      fire(0.5, 0.5, 150);
      setTimeout(() => fire(0.2, 0.55, 70), 300);
      setTimeout(() => fire(0.8, 0.55, 70), 450);
    }
  }, [allOut, fire]);
  useEffect(() => () => stopMic.current(), []);

  return (
    <section className="px-5 py-24">
      <Title eyebrow={`${AGE} ngọn nến cho tuổi ${AGE}`}>Hãy ước một điều ước</Title>
      <Reveal>
        <div className="relative mx-auto w-full max-w-[400px]" style={{ aspectRatio: "400 / 330" }}>
          <div aria-hidden className="absolute left-1/2 top-[40%] h-[70%] w-[90%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-pink/20 blur-3xl" />
          <svg viewBox="0 0 400 330" className="absolute inset-0 h-full w-full" role="img" aria-label={`Chiếc bánh kem có ${AGE} ngọn nến`}>
            <ellipse cx="200" cy="300" rx="185" ry="16" fill="#ffd479" fillOpacity=".9" />
            <ellipse cx="200" cy="296" rx="185" ry="14" fill="#ffe9ad" />
            <rect x="40" y="205" width="320" height="86" rx="16" fill="#ff9ccf" />
            <path d={dripPath(40, 360, 215, 10)} fill="#fff1f8" />
            <rect x="70" y="128" width="260" height="82" rx="14" fill="#c9b6ff" />
            <path d={dripPath(70, 330, 138, 10)} fill="#fff" />
            <ellipse cx="200" cy="130" rx="130" ry="14" fill="#fff6fb" />
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
              <circle key={i} cx={58 + i * 40} cy={262 + (i % 2) * 6} r="5" fill={i % 2 ? "#ffd479" : "#fff"} />
            ))}
            {lit.map((on, i) => {
              const x = CAN_X(i), y = CAN_Y(i);
              return (
                <g key={i}>
                  <rect x={x - 3.5} y={y - 26} width="7" height="26" rx="2" fill={["#7cc6fe", "#ffd479", "#ff8fb0"][i % 3]} />
                  <path d={`M${x - 3.5} ${y - 16} l7 -4 M${x - 3.5} ${y - 8} l7 -4`} stroke="#fff" strokeWidth="1.6" opacity=".7" />
                  {on ? (
                    <g className="flame" style={{ animationDelay: `${(i % 5) * 0.08}s` }}>
                      <ellipse cx={x} cy={y - 36} rx="5.5" ry="9" fill="#ffd36b" />
                      <ellipse cx={x} cy={y - 34} rx="2.6" ry="5" fill="#ff7a45" />
                    </g>
                  ) : (
                    [0, 1].map((d) => (
                      <circle key={d} className="smoke" cx={x + d * 3 - 1.5} cy={y - 30} r="4" fill="#c9c2e8" style={{ animationDelay: `${d * 0.4}s` }} />
                    ))
                  )}
                </g>
              );
            })}
          </svg>
          <div
            onPointerDown={tap}
            role="button"
            aria-label="Chạm vào các ngọn nến để thổi tắt"
            className="absolute left-[8%] top-[10%] h-[34%] w-[84%] cursor-pointer touch-manipulation rounded-3xl"
          />
        </div>

        <div className="mt-8 text-center" aria-live="polite">
          {allOut ? (
            <>
              <p className="glow-gold font-script text-4xl font-bold text-gold md:text-5xl">Điều ước của bạn sẽ thành hiện thực</p>
              <button onClick={() => setLit(Array(AGE).fill(true))} className="mt-5 min-h-11 cursor-pointer rounded-full border border-white/25 px-5 text-sm text-mist hover:bg-white/10">
                Thắp lại nến
              </button>
            </>
          ) : (
            <>
              <p className="text-mist-soft">
                {mic === "on" ? "Đang lắng nghe… hãy chu môi thổi vào micro 🌬️" : mic === "denied" ? "Không dùng được micro — bạn hãy chạm vào các ngọn nến nhé." : "Nhắm mắt, ước thật lòng, rồi thổi nến."}
                <span className="ml-2 text-gold">Còn {left} ngọn</span>
              </p>
              {mic !== "on" && (
                <button onClick={startMic} className="mt-4 min-h-11 cursor-pointer rounded-full bg-gradient-to-r from-pink to-gold px-6 text-sm font-semibold text-night">
                  🎤 Thổi bằng micro
                </button>
              )}
              <p className="mt-3 text-xs text-mist-soft/80">Hoặc chạm trực tiếp vào bánh để tắt nến</p>
            </>
          )}
        </div>
      </Reveal>
    </section>
  );
}

/* ---------- Vòng ảnh 3D quanh trái tim ---------- */
function PhotoRing({ photos, reduced, onOpen }: { photos: { src: string; alt: string }[]; reduced: boolean; onOpen: (i: number) => void }) {
  const [vw, setVw] = useState(window.innerWidth);
  const ringRef = useRef<HTMLDivElement>(null);
  const angle = useRef(0);
  const vel = useRef(0);
  const drag = useRef<{ x: number; moved: number } | null>(null);
  const n = photos.length;

  useEffect(() => {
    const f = () => setVw(window.innerWidth);
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);

  const cw = vw < 640 ? 84 : 140;
  const ch = Math.round(cw * 1.35);
  const R = Math.round(cw / (2 * Math.tan(Math.PI / n)) + (vw < 640 ? 16 : 28));
  const auto = reduced ? 0 : 0.18;

  // Vòng lặp: tự xoay chậm + quán tính sau khi thả tay
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      if (!drag.current) {
        vel.current += (auto - vel.current) * 0.04;
        angle.current += vel.current;
      }
      if (ringRef.current) ringRef.current.style.transform = `rotateY(${angle.current}deg)`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [auto]);

  const down = (e: React.PointerEvent) => {
    drag.current = { x: e.clientX, moved: 0 };
    let lastX = e.clientX;
    const move = (ev: PointerEvent) => {
      if (!drag.current) return;
      const dx = ev.clientX - lastX;
      lastX = ev.clientX;
      drag.current.moved += Math.abs(dx);
      angle.current += dx * 0.45;
      vel.current = dx * 0.45;
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      setTimeout(() => (drag.current = null), 0);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  };

  return (
    <section className="overflow-x-clip px-4 py-24">
      <Title eyebrow="Kỷ niệm">Vòng quay ký ức</Title>
      <Reveal>
        <div className="ring-stage relative mx-auto h-[400px] w-full max-w-3xl md:h-[470px]" onPointerDown={down}>
          <div className="heart-beat pointer-events-none absolute left-1/2 top-[22%] z-10 -translate-x-1/2 text-[64px] leading-none md:top-[18%] md:text-[84px]" aria-hidden>
            <svg viewBox="0 0 32 29" className="h-[1em] w-[1em]">
              <path d="M16 28 C-6 12 4 -3 16 7 C28 -3 38 12 16 28Z" fill="url(#hg)" />
              <defs>
                <linearGradient id="hg" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#ffb3d9" />
                  <stop offset="1" stopColor="#ff4fa0" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <div className="ring-tilt absolute left-1/2 top-1/2" style={{ width: 0, height: 0 }}>
            <div ref={ringRef} className="ring absolute left-0 top-0" style={{ width: 0, height: 0 }}>
              {photos.map((p, i) => (
                <button
                  key={i}
                  onClick={() => drag.current && drag.current.moved > 6 ? undefined : onOpen(i)}
                  aria-label={`Phóng to: ${p.alt}`}
                  className="ring-card absolute overflow-hidden rounded-xl border border-white/25 shadow-[0_0_28px_rgba(255,116,184,0.35)]"
                  style={{ width: cw, height: ch, left: -cw / 2, top: -ch / 2, transform: `rotateY(${(360 / n) * i}deg) translateZ(${R}px)` }}
                >
                  <img src={p.src || placeholder(i)} alt={p.alt} loading="lazy" draggable={false} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>
        <p className="mt-2 text-center text-sm text-mist-soft">Kéo hoặc vuốt để xoay, chạm vào ảnh để phóng to</p>
      </Reveal>
    </section>
  );
}

/* ---------- Lời chúc: hiện dần như đang gõ ---------- */
function TypedWishes({ lines, reduced }: { lines: string[]; reduced: boolean }) {
  const [ref, seen] = useSeen(0.25);
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!seen) return;
    if (reduced) return setN(1e6);
    const id = setInterval(() => setN((v) => v + 1), 38);
    return () => clearInterval(id);
  }, [seen, reduced]);

  let offset = 0;
  return (
    <div ref={ref} className="space-y-6 text-center">
      {lines.map((l, i) => {
        const shown = Math.max(0, Math.min(l.length, n - offset));
        const active = shown > 0 && shown < l.length;
        offset += l.length + 12; // nghỉ một nhịp giữa các câu
        return (
          <p key={i} aria-label={l} className="relative text-lg leading-relaxed md:text-2xl">
            <span aria-hidden className="invisible">{l}</span>
            <span aria-hidden className="absolute inset-0">
              {l.slice(0, shown)}
              {active && <span className="caret" />}
            </span>
          </p>
        );
      })}
    </div>
  );
}

function WishesSection({ reduced }: { reduced: boolean }) {
  const stars = useMemo(() => Array.from({ length: 6 }, (_, i) => ({ left: (i * 17 + 5) % 70, top: (i * 13) % 40, d: 7 + (i % 4) * 2, delay: -i * 2.3 })), []);
  const lanterns = useMemo(() => Array.from({ length: 7 }, (_, i) => ({ left: 6 + i * 14, d: 20 + (i % 4) * 5, delay: -i * 4.7 })), []);
  return (
    <section className="relative overflow-hidden px-6 py-28">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        {stars.map((s, i) => (
          <span key={i} className="fstar" style={{ left: `${s.left}%`, top: `${s.top}%`, "--d": `${s.d}s`, "--delay": `${s.delay}s` } as CSSProperties} />
        ))}
        {lanterns.map((l, i) => (
          <span key={i} className="lantern" style={{ left: `${l.left}%`, "--d": `${l.d}s`, "--delay": `${l.delay}s` } as CSSProperties} />
        ))}
      </div>
      <div className="relative mx-auto max-w-2xl">
        <Title eyebrow="Lời chúc">Từ trái tim mình</Title>
        <TypedWishes lines={CONFIG.wishes} reduced={reduced} />
      </div>
    </section>
  );
}

/* ---------- Thư tay: viết từng dòng ---------- */
function LetterSection() {
  const [ref, seen] = useSeen(0.25);
  const lines = CONFIG.letter;
  return (
    <section className="px-5 py-24">
      <Title eyebrow="Lá thư cuối">Vài dòng viết tay</Title>
      <Reveal className="mx-auto max-w-2xl">
        <div
          ref={ref}
          className={`rounded-2xl p-7 text-parchment-ink shadow-[0_0_80px_-10px_rgba(255,212,121,0.45)] md:p-12 ${seen ? "in" : ""}`}
          style={{ backgroundColor: "var(--color-parchment)", backgroundImage: "repeating-linear-gradient(transparent 0 41px, rgba(120,90,160,0.25) 41px 42px)", backgroundPosition: "0 26px" }}
        >
          {lines.map((l, i) => (
            <p key={i} className="mb-5 font-script text-2xl font-medium leading-[1.6] md:text-3xl">
              <span className="write inline-block" style={{ transitionDelay: `${i * 1.3}s` }}>{l}</span>
            </p>
          ))}
          <p className="mt-6 text-right font-script text-4xl font-bold text-[#c2306f]">
            <span className="write inline-block" style={{ transitionDelay: `${lines.length * 1.3}s` }}>— {CONFIG.sender}</span>
          </p>
        </div>
      </Reveal>
    </section>
  );
}

/* =====================================================================
   APP
   ===================================================================== */
type Stage = "intro" | "countdown" | "scene" | "main";

export default function App() {
  const reduced = useReducedMotion();
  const { canvasRef, fire } = useConfetti(reduced);
  const music = useMusic();
  const [stage, setStage] = useState<Stage>("intro");
  const [count, setCount] = useState(3);
  const [lightbox, setLightbox] = useState<number | null>(null);

  const photos = useMemo(() => CONFIG.photos, []);

  // Khóa cuộn khi đang chạy các màn mở đầu
  useEffect(() => {
    document.body.style.overflow = stage === "main" ? "" : "hidden";
  }, [stage]);

  const open = () => {
    music.start(); // trình duyệt chỉ cho phát nhạc sau lần chạm đầu tiên
    setCount(3);
    setStage("countdown");
  };

  // Đếm ngược 3 → 2 → 1
  useEffect(() => {
    if (stage !== "countdown") return;
    const id = setTimeout(() => {
      if (count > 1) setCount(count - 1);
      else setStage(reduced ? "main" : "scene");
    }, reduced ? 500 : 1000);
    return () => clearTimeout(id);
  }, [stage, count, reduced]);

  const sceneDone = useCallback(() => {
    window.scrollTo(0, 0);
    setStage("main");
    fire(0.5, 0.4, 140);
  }, [fire]);

  const replay = () => {
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
    setTimeout(() => {
      window.scrollTo(0, 0);
      setStage("intro");
    }, reduced ? 0 : 600);
  };

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
      if (e.key === "ArrowRight") setLightbox((v) => (v! + 1) % photos.length);
      if (e.key === "ArrowLeft") setLightbox((v) => (v! - 1 + photos.length) % photos.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox, photos.length]);

  return (
    <div className="relative min-h-svh overflow-x-clip">
      <StarField reduced={reduced} />
      <canvas ref={canvasRef} aria-hidden className="pointer-events-none fixed inset-0 z-[70]" />

      {/* ===== 1. MÀN HÌNH MỞ ĐẦU ===== */}
      {stage === "intro" && (
        <div className="fade-in fixed inset-0 z-[50] flex flex-col items-center justify-center px-6 text-center">
          <p className="font-script text-3xl text-mist md:text-4xl">Có một món quà dành cho</p>
          <h1 className="glow-gold mt-1 font-script text-6xl font-bold text-gold md:text-8xl">{CONFIG.shortName}</h1>
          <button
            onClick={open}
            className="btn-glow mt-12 min-h-14 cursor-pointer rounded-full bg-gradient-to-r from-pink to-gold px-10 text-lg font-semibold text-night transition active:scale-95"
          >
            🎁 Mở quà
          </button>
        </div>
      )}

      {/* ===== 2. ĐẾM NGƯỢC ===== */}
      {stage === "countdown" && (
        <div className="fixed inset-0 z-[50] flex items-center justify-center" aria-live="assertive">
          <span key={count} className="count-pop glow-gold font-script text-[10rem] font-bold leading-none text-gold md:text-[16rem]">
            {count}
          </span>
        </div>
      )}

      {/* ===== 3. HẠT XẾP CHỮ + PHÁO HOA ===== */}
      {stage === "scene" && <ParticleScene onDone={sceneDone} />}

      {/* ===== 4 → 8: NỘI DUNG CHÍNH ===== */}
      {stage === "main" && (
        <main className="fade-in relative z-10">
          <header className="px-6 pt-16 text-center">
            <p className="text-xs uppercase tracking-[0.3em] text-pink">{CONFIG.birthday} · Tuổi {CONFIG.age}</p>
            <h1 className="glow-gold mt-2 font-script text-5xl font-bold text-gold md:text-7xl">Chúc mừng sinh nhật {CONFIG.shortName}!</h1>
          </header>

          <Cake fire={fire} />
          <PhotoRing photos={photos} reduced={reduced} onOpen={setLightbox} />
          <WishesSection reduced={reduced} />
          <LetterSection />

          {/* ===== 8. KẾT ===== */}
          <footer className="px-6 pb-32 pt-16 text-center">
            <button onClick={replay} className="min-h-12 cursor-pointer rounded-full border border-gold/60 px-8 text-sm font-medium text-gold transition hover:bg-gold/10">
              ↻ Xem lại từ đầu
            </button>
            <p className="mt-8 text-mist-soft">Made with ❤️ by {CONFIG.sender}</p>
          </footer>
        </main>
      )}

      {/* Nút nhạc cố định */}
      <button
        onClick={() => (music.playing ? music.stop() : music.start())}
        aria-label={music.playing ? "Tắt nhạc nền" : "Bật nhạc nền"}
        aria-pressed={music.playing}
        className="fixed bottom-4 right-4 z-[90] flex h-12 w-12 cursor-pointer items-center justify-center rounded-full border border-white/25 bg-night-2/80 text-xl shadow-lg backdrop-blur transition hover:scale-105"
      >
        {music.playing ? "🔊" : "🔇"}
      </button>

      {/* Lightbox */}
      {lightbox !== null && (
        <div role="dialog" aria-modal="true" aria-label="Xem ảnh phóng to" className="fixed inset-0 z-[80] flex items-center justify-center bg-night/95 p-4" onClick={() => setLightbox(null)}>
          <img src={photos[lightbox].src || placeholder(lightbox)} alt={photos[lightbox].alt} className="max-h-[85vh] max-w-full rounded-2xl object-contain shadow-[0_0_60px_rgba(255,116,184,0.4)]" onClick={(e) => e.stopPropagation()} />
          <button autoFocus onClick={() => setLightbox(null)} aria-label="Đóng" className="absolute right-4 top-4 h-11 w-11 cursor-pointer rounded-full bg-white/15 text-2xl text-white hover:bg-white/30">×</button>
          <button onClick={(e) => { e.stopPropagation(); setLightbox((lightbox - 1 + photos.length) % photos.length); }} aria-label="Ảnh trước" className="absolute left-3 top-1/2 h-11 w-11 -translate-y-1/2 cursor-pointer rounded-full bg-white/15 text-2xl text-white hover:bg-white/30">‹</button>
          <button onClick={(e) => { e.stopPropagation(); setLightbox((lightbox + 1) % photos.length); }} aria-label="Ảnh sau" className="absolute right-3 top-1/2 h-11 w-11 -translate-y-1/2 cursor-pointer rounded-full bg-white/15 text-2xl text-white hover:bg-white/30">›</button>
        </div>
      )}
    </div>
  );
}
